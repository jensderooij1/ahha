"""Albert Heijn integration for Home Assistant."""
DOMAIN = "albert_heijn"